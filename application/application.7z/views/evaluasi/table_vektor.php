

<table id="listAlternatif" class="table table-bordered table-bordered">
    <thead>
        <tr>
            <th rowspan="2" style="vertical-align: middle ;text-align:center">NISN</th>
            <th rowspan="2" style="vertical-align: middle ;text-align:center">Nama</th>
            <th colspan="3" style="vertical-align: middle ;text-align:center">Nilai Alternatif</th>
            <th rowspan="2" style="vertical-align: middle ;text-align:center">Kesimpulan</th>

        </tr>
        <tr>
            <th style="vertical-align: middle ;text-align:center">MIA</th>
            <th style="vertical-align: middle ;text-align:center">IIS</th>
            <th style="vertical-align: middle ;text-align:center">Bahasa</th>
        </tr>
    </thead>
    <tbody>
        <?php
        echo $data_tahun;
        // $no = 1;
        // foreach ($vektor as $row) {
        //     echo "<tr><td>" . $row['nis'] . "</td>";
        //     echo "<td>" . $row['nama'] . "</td>";
        //     echo "<td>" . $row['vektor_s'] . "</td>";
        //     echo "<td>" . $row['vektor_v'] . "</td>";
        //     echo "<td>" . $no . "</td></tr>";
        //     $no++;
        // }
        ?>
    </tbody>
</table>